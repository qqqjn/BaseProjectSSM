package com.baoshi.programmer.dao.admin;

import com.baoshi.programmer.entity.admin.Student;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface StudentDao {
    public  int add(Student student);

    public  int edit(Student student);
    public List<Student> findList(Map<String, Object> queryMap);
    public int delete(Long id);

    public  Integer getTotal(Map<String, Object> queryMap);

    public  Student findByName(String name);
}

package com.baoshi.programmer.dao.admin;

import com.baoshi.programmer.entity.admin.Exam;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface ExamDao {
    public  int add(Exam exam);

    public  int edit(Exam exam);
    public List<Exam> findList(Map<String, Object> queryMap);
    public int delete(Long id);

    public  Integer getTotal(Map<String, Object> queryMap);

    public  Exam findByName(String name);
}

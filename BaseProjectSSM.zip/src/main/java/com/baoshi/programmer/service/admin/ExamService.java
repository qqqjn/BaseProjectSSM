package com.baoshi.programmer.service.admin;

import com.baoshi.programmer.entity.admin.Exam;
import com.baoshi.programmer.entity.admin.Student;

import java.util.List;
import java.util.Map;

public interface ExamService {
    public  int add(Exam exam);

    public  int edit(Exam exam);
    public List<Exam> findList(Map<String, Object> queryMap);
    public int delete(Long id);

    public  Integer getTotal(Map<String, Object> queryMap);

    public  Exam findByName(String name);
}

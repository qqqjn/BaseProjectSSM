package com.baoshi.programmer.service.admin.impl;

import com.baoshi.programmer.dao.admin.StudentDao;
import com.baoshi.programmer.dao.admin.SubjectDao;
import com.baoshi.programmer.entity.admin.Student;
import com.baoshi.programmer.entity.admin.Subject;
import com.baoshi.programmer.service.admin.StudentService;
import com.baoshi.programmer.service.admin.SubjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * 考生的service实现类
 */
@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentDao studentDao;


    @Override
    public int add(Student student) {
        return studentDao.add(student);
    }

    @Override
    public int edit(Student student) {
        return studentDao.edit(student);
    }

    @Override
    public List<Student> findList(Map<String, Object> queryMap) {
        return studentDao.findList(queryMap);
    }

    @Override
    public int delete(Long id) {
        return studentDao.delete(id);
    }

    @Override
    public Integer getTotal(Map<String, Object> queryMap) {
        return studentDao.getTotal(queryMap);
    }

    @Override
    public Student findByName(String name) {
        return  studentDao.findByName(name);
    }
}

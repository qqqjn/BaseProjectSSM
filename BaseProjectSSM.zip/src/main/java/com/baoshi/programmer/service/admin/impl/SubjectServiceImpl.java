package com.baoshi.programmer.service.admin.impl;

import com.baoshi.programmer.dao.admin.SubjectDao;
import com.baoshi.programmer.entity.admin.Subject;
import com.baoshi.programmer.service.admin.SubjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * 学科专业的service实现类
 */
@Service
public class SubjectServiceImpl implements SubjectService {

    @Autowired
    private SubjectDao subjectDao;

    @Override
    public int add(Subject subject) {
        return subjectDao.add(subject);
    }

    @Override
    public int edit(Subject subject) {
        return subjectDao.edit(subject);
    }

    @Override
    public List<Subject> findList(Map<String, Object> queryMap) {
        return subjectDao.findList(queryMap);
    }

    @Override
    public int delete(Long id) {
        return subjectDao.delete(id);
    }

    @Override
    public Integer getTotal(Map<String, Object> queryMap) {
        return subjectDao.getTotal(queryMap);
    }
}

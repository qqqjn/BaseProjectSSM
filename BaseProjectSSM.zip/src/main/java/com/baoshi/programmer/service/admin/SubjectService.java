package com.baoshi.programmer.service.admin;

import com.baoshi.programmer.entity.admin.Subject;

import java.util.List;
import java.util.Map;

/**
 * 学科专业的service类
 */
public interface SubjectService {

    public  int add(Subject subject);

    public  int edit(Subject subject);
    public List<Subject> findList(Map<String,Object> queryMap);
    public int delete(Long id);

    public  Integer getTotal(Map<String,Object> queryMap);
}

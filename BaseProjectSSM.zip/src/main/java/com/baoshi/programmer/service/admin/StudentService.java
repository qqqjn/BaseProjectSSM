package com.baoshi.programmer.service.admin;

import com.baoshi.programmer.entity.admin.Student;
import com.baoshi.programmer.entity.admin.Subject;

import java.util.List;
import java.util.Map;

/**
 * 考生的service类
 */
public interface StudentService {

    public  int add(Student student);

    public  int edit(Student student);
    public List<Student> findList(Map<String, Object> queryMap);
    public int delete(Long id);

    public  Integer getTotal(Map<String, Object> queryMap);

    public  Student findByName(String name);
}

package com.baoshi.programmer.controller.admin;

import com.baoshi.programmer.entity.admin.Exam;
import com.baoshi.programmer.page.admin.Page;
import com.baoshi.programmer.service.admin.ExamService;
import com.baoshi.programmer.service.admin.SubjectService;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/admin/exam")
public class ExamController {

    @Autowired
    private ExamService examService;
    @Autowired
    private SubjectService subjectService;

    @RequestMapping(value = "/list",method = RequestMethod.GET)
    public ModelAndView list(ModelAndView model){
        Map<String,Object> queryMap=new HashMap<String, Object>();
        queryMap.put("offset",0);
        queryMap.put("pageSize",999);
        model.addObject("subjectList",subjectService.findList(queryMap));
        model.addObject("examList",examService.findList(queryMap));
        model.setViewName("/exam/list");
        return  model;
    }

    /**
     * 根据搜索分页查询列表数据
     * @param name
     * @param page
     * @return
     */
    @RequestMapping(value = "/list",method = RequestMethod.POST)
    @ResponseBody
    public  Map<String,Object> list(@RequestParam(name = "name",defaultValue ="")String name,
                                    @RequestParam(name = "subjectId" ,required = false)Long subjectId, Page page){
        Map<String,Object> ret= new HashMap<String, Object>();
        Map<String,Object> queryMap= new HashMap<String, Object>();
        queryMap.put("name",name);
        if (subjectId!=null){
            queryMap.put("subjectId",subjectId);
        }
        queryMap.put("offset",page.getOffset());
        queryMap.put("pageSize",page.getRows());
        ret.put("rows",examService.findList(queryMap));
        ret.put("total",examService.getTotal(queryMap));
        return ret;

    }


    @RequestMapping(value = "/add" ,method = RequestMethod.POST)
    @ResponseBody
    public Map<String,String> add(Exam exam){
        //System.out.println("11111");
        Map<String,String>  ret= new HashMap<String, String>();
        if (exam==null){
            ret.put("type","error");
            ret.put("msg","请填写正确的试卷信息");
            return  ret;
        }
        if (StringUtils.isEmpty(exam.getName())){
            ret.put("type","error");
            ret.put("msg","请填写试卷名");
            return  ret;
        }
        if (exam.getSubjectId()==null){
            ret.put("type","error");
            ret.put("msg","请选择试卷所属学科!!");
            return  ret;
        }
        exam.setCreateTime(new Date());
        //判断登录名是否存在
        if(isExistName(exam.getName(),-1L)){
            ret.put("type","error");
            ret.put("msg","该登录账号已经存在!!");
            return  ret;
        }
        if (examService.add(exam)<=0){
            ret.put("type","error");
            ret.put("msg","添加失败，请联系管理员!!");
            return  ret;
        }
        ret.put("type","success");
        ret.put("msg","添加成功！！！");
        return  ret;
    }

    /**
     * 编辑考试信息
     * @param exam
     * @return
     */
    @RequestMapping(value = "/edit",method = RequestMethod.POST)
    @ResponseBody
    public  Map<String,String> edit(Exam exam){
        Map<String,String>  ret= new HashMap<String, String>();
        if (exam==null){
            ret.put("type","error");
            ret.put("msg","请填写正确的试卷信息");
            return  ret;
        }
        if (StringUtils.isEmpty(exam.getName())){
            ret.put("type","error");
            ret.put("msg","请填写试卷名");
            return  ret;
        }
        if (StringUtils.isEmpty(String.valueOf(exam.getStartTime()))){
            ret.put("type","error");
            ret.put("msg","请填写考试开始时间");
            return  ret;
        } if (StringUtils.isEmpty(String.valueOf(exam.getEndTime()))){
            ret.put("type","error");
            ret.put("msg","请填写考试结束时间");
            return  ret;
        }
        if (exam.getSubjectId()==null){
            ret.put("type","error");
            ret.put("msg","请选择试卷所属学科!!");
            return  ret;
        }
        //编辑之前判断登录之前是否存在
        if (isExistName(exam.getName(),exam.getId())){
            ret.put("type","error");
            ret.put("msg","该登陆账号已经存在!!");
            return  ret;
        }
        if (examService.edit(exam)<=0){
            ret.put("type","error");
            ret.put("msg","添加失败，请联系管理员!!");
            return  ret;
        }
        ret.put("type","success");
        ret.put("msg","编辑成功！！！");
        return  ret;

    }

    /**
     * 删除考生信息
     * @param id
     * @return
     */
    @RequestMapping(value = "/delete",method = RequestMethod.POST)
    @ResponseBody
    public Map<String,String> delete(Long id){
        Map<String,String>  ret= new HashMap<String, String>();
        if(id==null){
            ret.put("type","error");
            ret.put("msg","请选择要删除的数据");
            return ret;
        }

        try {
            if (examService.delete(id)<=0){
                ret.put("type","error");
                ret.put("msg","删除失败请联系管理员!");
                return ret;
            }
        }catch (Exception e){
            ret.put("type","error");
            ret.put("msg","该考生下存在考试信息，不能删除!");
            return ret;
        }

        ret.put("type","success");
        ret.put("msg","删除成功!");
        return ret;
    }

    public  boolean isExistName(String name,Long id){
        Exam exam= examService.findByName(name);
        if (exam==null){
            return  false;
        }
        if (exam.getId().longValue()==id.longValue()){
            return  false;
        }
        return true;
    }


}
